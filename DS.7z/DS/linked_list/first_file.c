#include<stdio.h>
void main()
{
	printf("hello\n");
	system("pause");
}