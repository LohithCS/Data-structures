void finish()
{
	printf("the program ends here\n");
}